README.txt file for sclc and cdiff distribution for Unix
********************************************************

This distribution should comprise the following files:
  README.txt -- this file
  sclc-cdiff.html -- HTML file with description and instructions,
                     ***NOTE***: this is the main file to read!
  sclc.html -- HTML manual page for sclc
  cdiff.html -- HTML manual page for cdiff
  sclc -- sclc Perl script.
  cdiff -- cdiff Perl script.

Dont forget to make sclc and cdiff executable when you install on Unix!
