#include <stdio.h>
#ifdef VMS
#include <types.h>
#else
#include <sys/types.h>
#endif
#ifdef PC
#include <fcntl.h>
#include <stdlib.h>
#include <malloc.h>
#else
#ifdef VMS
#include <file.h>
#else
#include <sys/file.h>
#endif
#endif
#include "vort.h"

extern long	lseek();

/*
 * imagepos
 *
 *	position the image file at pixel x, y. (at the moment this just
 * goes to (0, 0)).
 */
int
imagepos(im, x, y)
	image	*im;
	int	x, y;
{
	im->ebufp = im->ibufp = im->ibuf + im->ibufsize;

	return(lseek(im->fd, (long)im->imaddr, 0));
}
