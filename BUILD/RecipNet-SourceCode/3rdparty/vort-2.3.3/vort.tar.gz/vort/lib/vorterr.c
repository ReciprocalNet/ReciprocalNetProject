#include <stdio.h>
#include "status.h"

/*
 * vorterror
 *
 * prints out an error message and then exits.
 *
 */
vorterror(s)
	char	*s;
{
	fprintf(stderr, s);
	exit(ERROR);
}

/*
 * vortwarning
 *
 * prints out a non-fatal error message.
 *
 */
vortwarning(s)
	char	*s;
{
	fprintf(stderr, s);
}
