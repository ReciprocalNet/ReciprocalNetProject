
/*
 * on VMS exit 0 is bad and 1 is good (sigh).
 */
#ifdef VMS
#define ALLOK		1
#define ERROR		0
#else 
#define ALLOK		0
#define ERROR		1
#endif

