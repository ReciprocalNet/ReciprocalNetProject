#include <stdio.h>
#include <math.h>
#include "gl.h"
#include "device.h"
#include "vort.h"
 
/*
 * simple program to display rgb files
 */
main(ac, av)
        int     ac;
        char    **av;
{                     
        image           *im;
        char            title[BUFSIZ], name[BUFSIZ];
        int             i, x, y;                
	short		val;
        unsigned short  h, w;
        unsigned char   *red, *green, *blue;
                                             
        if ((im = openimage(av[1], "r")) == (image *)NULL) {
                fprintf(stderr, "disp: can't open file %s.\n", av[1]);
                 exit(1);
        }    
              
        w = imagewidth(im);
        h = imageheight(im);

        red = (unsigned char *)malloc(w);
        green = (unsigned char *)malloc(w);
        blue = (unsigned char *)malloc(w);

        strcpy(name, imagetitle(im));
                                      
        prefsize((Scoord)w, (Scoord)h);
        winopen(name);
        RGBmode();     
        gconfig();
        qdevice(QKEY);
        qdevice(REDRAW);

        y = h - 1;
        while (readrgbline(im, red, green, blue)) {
                cmov2i(0, y);
                writeRGB(w, red, green, blue);
                y--;
        }
          
        while((i = qread(&val)) != QKEY)
                if (i == REDRAW) {
                        imagepos(im, 0, 0);
			y = h - 1;
                        while (readrgbline(im, red, green, blue)) {
                                cmov2i(0, y);                       
                                writeRGB(w, red, green, blue);
                                y--;                           
                        }
                }         

        exit(0);
}
