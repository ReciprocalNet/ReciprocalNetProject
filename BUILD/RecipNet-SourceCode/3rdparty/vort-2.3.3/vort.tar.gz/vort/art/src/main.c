#include <stdio.h>
#include <math.h>
#ifdef PC
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#define rindex strrchr
#else
#ifdef SYSV
#include <fcntl.h>
#else
#ifdef VMS
#include <types.h>
#include <file.h>
#else
#include <sys/types.h>
#include <sys/file.h>
#endif
#endif
#endif
#ifdef VMS
#include <string.h>
#define rindex strrchr
#endif
#ifdef MIPS
#include <string.h>
#define rindex strrchr
#endif
#ifdef PC
#ifdef TC
#include <time.h>
#ifdef _STKLEN
unsigned _stklen = _STKLEN;
#else
unsigned _stklen = 8192 * 2 * 2;
#endif
#else
#include <sys/timeb.h>
#endif
#else
#include <sys/times.h>
#endif
#ifdef CRAY
#include <string.h>
#define rindex strrchr
#endif

#include "art.h"
#include "objs.h"
#include "macro.h"
#include "gram.h"

extern char	*rindex();
extern hlist	*trace();
extern void	shade();
extern time_t	time();

extern object	*treeinit();

FILE	*logfile;

/*
 * statistics stuff
 */
#ifdef STATS
static int	totnodes;
static int	totleafs;
static int	neverentered;
static int	maxfinaldepth;
static int	maxinleaf;
static int	mininleaf;
static int	emptynodes;
static int	numobjptrs;
#endif

#ifdef TIME_STATS
static float    prev_time;
static time_t  start_time, rprev_time, tstart_time;
static struct tms       buffer;
#endif

#ifdef PC
int	EMS_available = FALSE;
void	ctrl_C(void);	/* CTRL-C trap processor */

#endif

extern int	chatty;

/*
 * object list - defined in render.c
 */
extern object	*oblist, *treeobjs;

/*
 * frame id extension and frame number
 */
char	*frameid = "000";
int	frameno = 0;

/*
 * default name
 */
char	*defname = "pic.pix";

/*
 * temporary file pointer
 */
char	*tmpname;


static int	totobjs;

/*
 * debugging flag.
 */
int	debug = FALSE;

/*
 * usage
 *
 *	print out usage details for art.
 */
usage(s)
	char    *s;
{
	if (s != (char *)NULL)
		warning(s);

	fatal("usage: art [-v] file.scn x_res y_res [-x x1 x2] [-y y1 y2] [-f frameid] [-o outputname] [-n] [-D var=expr]\n");
}

/*
 * main driver
 */
main(ac, av)
	int	ac;
	char	*av[];
{
	int		indx, standardin, preprocess, nameset;
	char		*p, name[100], fname[100], buf[100];
	FILE		*infile;
	int		i, fragment, xsize, ysize, xstart, xend, ystart, yend;
	image		*im;
	object		*o;
#ifdef LOSINGTRACK
	char		hostname[65], pathname[513];
#endif

#ifndef VMS
	logfile = stdout;
#endif

	if (ac < 4)
		usage((char *)NULL);

#ifdef TIME_STATS
	times(&buffer);
	start_time = buffer.tms_utime + buffer.tms_stime;
#endif

#ifdef PC
	if (EMS_rdy()) EMS_available = TRUE;
	signal(SIGINT, ctrl_C); 			/* trap user aborts */
#endif

	if (strcmp(av[1], "-v") == 0) {
		indx = 2;
		chatty = TRUE;
	} else {
		chatty = FALSE;
		indx = 1;
	}

	xsize = atoi(av[indx + 1]);
	ysize = atoi(av[indx + 2]);

	xstart = 0;
	xend = xsize - 1;

	ystart = ysize - 1;
	yend = 0;

	preprocess = TRUE;
	nameset = FALSE;
	standardin = FALSE;
	fragment = FALSE;
					/* check for other options */
	for (i = indx + 3; i < ac; i++) {
		if (strcmp(av[i], "-y") == 0) {
			if (av[i + 1] == (char *)NULL)
				usage("art: -y requires two numbers.\n");
			if (av[i + 2] == (char *)NULL)
				usage("art: -y requires two numbers.\n");
			ystart = ysize - atoi(av[i + 1]) - 1;
			yend = ysize - atoi(av[i + 2]) - 1;
			fragment = TRUE;
			i += 2;
		} else if (strcmp(av[i], "-x") == 0) {
			if (av[i + 1] == (char *)NULL)
				usage("art: -x requires two numbers.\n");
			if (av[i + 2] == (char *)NULL)
				usage("art: -x requires two numbers.\n");
			xstart = atoi(av[i + 1]);
			xend = atoi(av[i + 2]);
			fragment = TRUE;
			i += 2;
		} else if (strcmp(av[i], "-D") == 0) {
			if (av[i + 1] == (char *)NULL)
				usage("art: -D requires an assignment string.\n");
			doassignment(av[i + 1]);
			i += 1;
		} else if (strcmp(av[i], "-f") == 0) {
			if (av[i + 1] == (char *)NULL)
				usage("art: -f requires frame identifier.\n");
			frameid = av[i + 1];
			if ('0' <= frameid[0] && '9' >= frameid[0])
				frameno = atoi(frameid);
			i += 1;
		} else if (strcmp(av[i], "-o") == 0) {
			if (av[i + 1] == (char *)NULL)
				usage("art: -o requires name.\n");
			defname = av[i + 1];
			nameset = TRUE;
			i += 1;
		} else if (strcmp(av[i], "-n") == 0) {
			preprocess = FALSE;
		} else {
			sprintf(buf, "art: unknown option %s.\n", av[i]);
			usage(buf);
		}
	}

	if (strcmp(av[indx], "-") == 0)
		standardin = TRUE;
		
	if (standardin || nameset) {
		strcpy(name, defname);

		if ((p = rindex(name, '.')) == (char *)NULL)
			fatal("art: output file should end with \".pix\".\n");
	} else {
		strcpy(name, av[indx]);

		if ((p = rindex(name, '.')) == (char *)NULL)
			fatal("art: input file should end with \".scn\".\n");
		standardin = FALSE;
	}

	strcpy(p, ".log");

	if ((logfile = fopen(name, "w")) == NULL) {
		sprintf(buf, "art: unable to open %s for writing.\n", name);
		fatal(buf);
	}

#ifdef LOSINGTRACK
	gethostname(hostname, 64);
	getwd(pathname, 512);
	fprintf(logfile, "Host: %s	Directory: %s\n", hostname, pathname);
	fflush(logfile);
#endif

	if (!standardin) {
		if (preprocess) {
			strcpy(fname, name);
			strcpy(rindex(fname, '.'), "XXXXXX");
			mktemp(fname);

			if ((infile = fopen(fname, "w")) == NULL) {
				sprintf(buf, "art: unable to open temporary file %s.\n", name);
				fatal(buf);
			}

			prepro(av[indx], infile);

			fclose(infile);
		} else
			strcpy(fname, av[indx]);
	} else
		infile = stdin;

	if (!standardin) {
#ifdef PC
		if ((infile = freopen(fname, "rt", stdin)) == NULL) {
#else
		if ((infile = freopen(fname, "r", stdin)) == NULL) {
#endif
			sprintf(buf, "art: unable to open file %s.\n", av[indx]);
			fatal(buf);
		}
	}

#ifndef PC
	if (preprocess)
		unlink(fname);
#endif

	if (preprocess)
		tmpname = fname;
	else
		tmpname = (char *)NULL;

	strcpy(p, PIX_SUFFIX);

	imagebufsize(512);
	if ((im = openimage(name, "w")) == (image *)NULL) {
		sprintf(buf, "art: unable to open %s for writing\n", name);
		fatal(buf);
	}

	imagewidth(im) = xend - xstart + 1;
	imageheight(im) = ystart - yend + 1;

	imagedepth(im) = 24;

	imagedate(im) = time((time_t *)NULL);

	if (fragment) {
		imagefragment(im) = TRUE;
		imagexaddr(im) = xstart;
		imageyaddr(im) = ysize - 1 - ystart;
		imageorigwidth(im) = xsize;
		imageorigheight(im) = ysize;
	}

	render(infile, im, xsize, ysize, xstart, xend, ystart, yend);

#ifdef PC
	if (preprocess)
		unlink(fname);

	/* deallocate storage used by tile patterns, esp. EMS */
	uninit_tiles();
#endif

#ifdef TIME_STATS
	printtime("Total time taken             :");
#endif

#ifdef STATS
	totobjs = 0;
	for (o = oblist; o != (object *)NULL; o = o->nxt)
		totobjs++;

	sprintf(buf, "Total number of objects           : %d\n", totobjs);
	message(buf);

	if (treeobjs != (object *)NULL && oblist->type == STREE) {
		mininleaf = totobjs;

		sprintf(buf, "Total number of tree nodes	: %d\n", totnodes);
		message(buf);
		sprintf(buf, "Number of leaf nodes not entered: %d\n", neverentered);
		message(buf);
		sprintf(buf, "Number of leaf nodes entered	: %d\n", totleafs);
		message(buf);
		sprintf(buf, "Number of object pointers	: %d\n", numobjptrs);
		message(buf);
		sprintf(buf, "Min number of objects in a leaf	: %d\n", mininleaf);
		message(buf);
		sprintf(buf, "Max number of objects in a leaf	: %d\n", maxinleaf);
		message(buf);
		sprintf(buf, "Max depth of a leaf node	: %d\n", maxfinaldepth);
		message(buf);
		sprintf(buf, "Number of empty nodes		: %d\n", emptynodes);
		message(buf);
	}
#endif

	fclose(logfile);

	exit(ALLOK);
}

#ifdef STATS
/*
 * getstats
 *
 *	calculate the statistics for the kd-tree pointed to by 
 * root.
 */
getstats(root)
	stree	*root;
{
	olist	*obs;
	int	count;

	totnodes++;

	if (root->type == SPLITABLELEAF)
		neverentered++;
	else if (root->type == LEAF) {
		if (maxfinaldepth < root->u.leaf.depth)
			maxfinaldepth = root->u.leaf.depth;
		if (root->u.leaf.oblist == (olist *)NULL)
			emptynodes++;
		else {
			count = 0;
			for (obs = root->u.leaf.oblist; obs != (olist *)NULL; obs = obs->nxt)
				count++;
			numobjptrs += count;
			if (mininleaf > count)
				mininleaf = count;
			if (maxinleaf < count)
				maxinleaf = count;
			totleafs++;
		}
	} else {
		getstats(root->u.branch.left);
		getstats(root->u.branch.right);
	}
}
#endif

#ifdef TIME_STATS
/*
 * printtime
 *
 *      print out how much time has been taken up.
 */
printtime(s)
	char    *s;
{
	float           diff;
	time_t          now;
	char            buf[BUFSIZ];

	times(&buffer);

	diff = buffer.tms_utime + buffer.tms_stime - start_time;

	sprintf(buf, "%s %.2f seconds.\n", s, diff / 60.0);       
	message(buf);
}

#endif

#ifdef PC
/****
 * Handle user abort requests.
 **/

void 	ctrl_C()
{
	signal(SIGINT, SIG_IGN);	/* ignore any abort requests in this routine */
	uninit_tiles();
	exit(1);
}
#endif




