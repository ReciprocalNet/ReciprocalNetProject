# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
#include <math.h>
#include "text3d.h"
#include "gram.h"

extern int	linecount;
extern double	atof();

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	return(OUTPUT);
break;
case 2:
	return(DRAWSTR);
break;
case 3:
	return(COLOUR);
break;
case 4:
	return(COLOUR);
break;
case 5:
return(TEXTSIZE);
break;
case 6:
	return(AMBIENT);
break;
case 7:
return(REFLECTANCE);
break;
case 8:
return(TRANSPARENCY);
break;
case 9:
return(MATERIAL);
break;
case 10:
return(TEXTRADIUS);
break;
case 11:
return(FIXEDWIDTH);
break;
case 12:
return(CENTERTEXT);
break;
case 13:
return(CENTERTEXT);
break;
case 14:
	return(TEXTANG);
break;
case 15:
	return(FONT);
break;
case 16:
return(DRAWCHAR);
break;
case 17:
	return(BOXFIT);
break;
case 18:
	return(BOXTEXT);
break;
case 19:
	return(MOVE);
break;
case 20:
	return(RMOVE);
break;
case 21:
	return(SCALE);
break;
case 22:
return(TRANSLATE);
break;
case 23:
	return(ROTATE);
break;
case 24:
return(FIXEDWIDTH);
break;
case 25:
return(CENTERTEXT);
break;
case 26:
	return(TRUE);
break;
case 27:
	return(FALSE);
break;
case 28:
	return(CYL_SPH);
break;
case 29:
	return(BOX_CYL);
break;
case 30:
{
			yylval.y_int = atoi(yytext);
			return(INTEGER);
		}
break;
case 31:
{
			yylval.y_flt = atof(yytext);
			return(FLOAT);
		}
break;
case 32:
	{
			int	braces = 1, c;
			while ((c = input()) != '{')
				if (c == '\n')
					linecount++;

			while (braces) {
				c = input();
				if (c == '\n')
					linecount++;

				if (c == '\\') {
					c = input();
					putchar(c);
					if (c == '\n')
						linecount++;
				} else {
					
					if (c == '{')
						braces++;
					if (c == '}')
						braces--;

					if (c == EOF) {
						fprintf(stderr, "Unterminated copy\n");
						exit(1);
					}

					if (braces)
						putchar(c);
				}
			}
			while ((c = input()) == '\n' || c == ' ' || c == '\t' )
				if (c == '\n')
					linecount++;

			unput(c);
			putchar('\n');
		}
break;
case 33:
	return(PLUS);
break;
case 34:
	return(MINUS);
break;
case 35:
	return(DIV);
break;
case 36:
	return(MULT);
break;
case 37:
	return(PCENT);
break;
case 38:
	return(POWER);
break;
case 39:
	return(COMMA);
break;
case 40:
	return(LP);
break;
case 41:
	return(RP);
break;
case 42:
	return(EQUALS);
break;
case 43:
	{
			int	c1, c2;

			c1 = input();

			if (c1 == '\\')
				c1 = input();

			if (c1 == '\n' || c1 == EOF)
				yyerror("syntax error");

			while((c2 = input()) != '\'')
				if (c2 == '\n' || c2 == EOF)
					yyerror("syntax error");
					
		 	
			yylval.y_int = c1;
			return(INTEGER);
		}
break;
case 44:
	{
			char	buf[BUFSIZ], *p;
			
			for (p = buf; (*p = input()) != '"'; p++) {
				if (*p == '\n' || *p == EOF) {
					sprintf(buf, "syntax error\n", linecount);
					yyerror(buf);
				}
					

				if (*p == '\\') 
					*p = input();
			}

			*p = 0;

			yylval.y_str = (char *)malloc(strlen(buf) + 1);
			strcpy(yylval.y_str, buf);

			return(STRING);
		}
break;
case 45:
	{
			return(LBRACE);
		}
break;
case 46:
	{
			return(RBRACE);
		}
break;
case 47:
	{
			linecount++;
		}
break;
case 48:
	{
			;
		}
break;
case 49:
	{
			int	c1, c2;
			int	comline, incomment = 1;
			char	buf[BUFSIZ];

			comline = linecount;

			do {
				while ((c1 = input()) != '*' && c1 != '/' && c1 != EOF)
					if (c1 == '\n')
						linecount++;

				c2 = input();
				if (c2 == '\n')
					linecount++;

				if (c1 == '*' && c2 == '/')
					incomment--;

				if (c1 == '/' && c2 == '*') {
					incomment++;
					comline = linecount;
				}

			} while (incomment && c2 != EOF);

			if (c1 == EOF || c2 == EOF) {
				fprintf(stderr, "text3d: unterminated comment - started line %d.\n", comline);
				exit(1);
			}
		}
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

30,
0,

30,
0,

48,
0,

47,
0,

44,
0,

37,
0,

43,
0,

40,
0,

41,
0,

36,
0,

33,
0,

39,
0,

34,
0,

31,
0,

35,
0,

30,
0,

42,
0,

38,
0,

45,
0,

46,
0,

49,
0,

32,
0,

15,
0,

19,
0,

26,
0,

4,
0,

27,
0,

20,
0,

21,
0,

17,
0,

3,
0,

1,
0,

23,
0,

6,
0,

29,
0,

18,
0,

28,
0,

2,
0,

14,
0,

16,
0,

9,
0,

5,
0,

22,
0,

12,
25,
0,

13,
0,

11,
24,
0,

10,
0,

7,
0,

8,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	1,4,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,3,	0,0,	1,5,	
0,0,	0,0,	1,6,	0,0,	
1,7,	1,8,	1,9,	1,10,	
1,11,	1,12,	1,13,	1,14,	
1,15,	1,16,	1,16,	1,16,	
1,16,	1,16,	1,16,	1,16,	
1,16,	1,16,	1,16,	15,31,	
0,0,	0,0,	1,17,	14,14,	
14,14,	14,14,	14,14,	14,14,	
14,14,	14,14,	14,14,	14,14,	
14,14,	16,14,	0,0,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,18,	
0,0,	0,0,	1,19,	1,20,	
1,21,	1,22,	27,47,	1,23,	
32,50,	37,56,	23,38,	24,41,	
21,34,	0,0,	1,24,	19,32,	
1,25,	20,33,	23,39,	1,26,	
1,27,	1,28,	21,35,	22,37,	
23,40,	24,42,	25,43,	26,44,	
1,29,	28,48,	1,30,	33,51,	
21,36,	34,52,	35,53,	26,45,	
36,55,	26,46,	35,54,	38,57,	
39,58,	40,59,	28,49,	41,60,	
42,61,	43,62,	44,63,	45,64,	
46,65,	47,66,	48,67,	49,68,	
50,70,	51,71,	52,74,	53,75,	
54,76,	55,77,	56,78,	57,79,	
51,72,	58,80,	59,81,	60,82,	
61,83,	62,84,	63,85,	64,86,	
65,87,	66,88,	67,89,	49,69,	
68,90,	69,91,	51,73,	70,92,	
71,93,	72,94,	73,95,	74,96,	
75,98,	77,100,	78,101,	75,99,	
79,103,	80,104,	82,105,	84,106,	
85,107,	86,108,	87,109,	88,110,	
74,97,	89,111,	90,114,	92,115,	
93,116,	94,117,	78,102,	95,118,	
96,119,	97,120,	99,121,	100,122,	
101,123,	102,124,	104,125,	105,126,	
106,127,	107,128,	89,112,	89,113,	
109,129,	111,130,	112,131,	113,132,	
114,133,	115,135,	116,136,	118,137,	
114,134,	119,138,	120,139,	122,140,	
123,141,	124,142,	125,143,	126,144,	
128,145,	130,146,	131,147,	132,148,	
133,149,	134,150,	138,151,	139,152,	
141,153,	143,154,	144,155,	145,156,	
147,157,	148,158,	149,159,	150,160,	
151,161,	152,162,	154,163,	156,164,	
157,165,	159,166,	160,167,	161,168,	
162,169,	163,170,	164,171,	165,172,	
167,173,	171,174,	173,175,	175,176,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+1,	0,		yyvstop+1,
yycrank+0,	yysvec+1,	yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+23,
yycrank+0,	0,		yyvstop+25,
yycrank+15,	0,		yyvstop+27,
yycrank+17,	0,		yyvstop+29,
yycrank+27,	0,		yyvstop+31,
yycrank+0,	0,		yyvstop+33,
yycrank+0,	0,		yyvstop+35,
yycrank+2,	0,		0,	
yycrank+2,	0,		0,	
yycrank+7,	0,		0,	
yycrank+5,	0,		0,	
yycrank+9,	0,		0,	
yycrank+10,	0,		0,	
yycrank+5,	0,		0,	
yycrank+22,	0,		0,	
yycrank+3,	0,		0,	
yycrank+24,	0,		0,	
yycrank+0,	0,		yyvstop+37,
yycrank+0,	0,		yyvstop+39,
yycrank+0,	0,		yyvstop+41,
yycrank+6,	0,		0,	
yycrank+7,	0,		0,	
yycrank+19,	0,		0,	
yycrank+22,	0,		0,	
yycrank+24,	0,		0,	
yycrank+8,	0,		0,	
yycrank+27,	0,		0,	
yycrank+16,	0,		0,	
yycrank+27,	0,		0,	
yycrank+23,	0,		0,	
yycrank+22,	0,		0,	
yycrank+25,	0,		0,	
yycrank+40,	0,		0,	
yycrank+32,	0,		0,	
yycrank+28,	0,		0,	
yycrank+48,	0,		0,	
yycrank+26,	0,		0,	
yycrank+50,	0,		0,	
yycrank+43,	0,		0,	
yycrank+54,	0,		0,	
yycrank+34,	0,		0,	
yycrank+40,	0,		0,	
yycrank+31,	0,		0,	
yycrank+58,	0,		0,	
yycrank+35,	0,		0,	
yycrank+40,	0,		0,	
yycrank+56,	0,		0,	
yycrank+42,	0,		0,	
yycrank+58,	0,		0,	
yycrank+59,	0,		0,	
yycrank+49,	0,		0,	
yycrank+54,	0,		0,	
yycrank+45,	0,		0,	
yycrank+67,	0,		0,	
yycrank+57,	0,		0,	
yycrank+50,	0,		0,	
yycrank+58,	0,		0,	
yycrank+68,	0,		0,	
yycrank+70,	0,		0,	
yycrank+73,	0,		0,	
yycrank+68,	0,		0,	
yycrank+73,	0,		0,	
yycrank+74,	0,		0,	
yycrank+62,	0,		0,	
yycrank+0,	0,		yyvstop+43,
yycrank+62,	0,		0,	
yycrank+79,	0,		0,	
yycrank+79,	0,		0,	
yycrank+81,	0,		0,	
yycrank+0,	0,		yyvstop+45,
yycrank+68,	0,		0,	
yycrank+0,	0,		yyvstop+47,
yycrank+66,	0,		0,	
yycrank+83,	0,		0,	
yycrank+84,	0,		0,	
yycrank+70,	0,		0,	
yycrank+86,	0,		0,	
yycrank+92,	0,		0,	
yycrank+75,	0,		0,	
yycrank+0,	0,		yyvstop+49,
yycrank+81,	0,		0,	
yycrank+71,	0,		0,	
yycrank+77,	0,		0,	
yycrank+75,	0,		0,	
yycrank+82,	0,		0,	
yycrank+96,	0,		0,	
yycrank+0,	0,		yyvstop+51,
yycrank+84,	0,		0,	
yycrank+87,	0,		0,	
yycrank+96,	0,		0,	
yycrank+85,	0,		0,	
yycrank+0,	0,		yyvstop+53,
yycrank+83,	0,		0,	
yycrank+98,	0,		0,	
yycrank+88,	0,		0,	
yycrank+106,	0,		0,	
yycrank+0,	0,		yyvstop+55,
yycrank+107,	0,		0,	
yycrank+0,	0,		yyvstop+57,
yycrank+99,	0,		0,	
yycrank+113,	0,		0,	
yycrank+106,	0,		0,	
yycrank+104,	0,		0,	
yycrank+97,	0,		0,	
yycrank+106,	0,		0,	
yycrank+0,	0,		yyvstop+59,
yycrank+99,	0,		0,	
yycrank+101,	0,		0,	
yycrank+102,	0,		0,	
yycrank+0,	0,		yyvstop+61,
yycrank+115,	0,		0,	
yycrank+123,	0,		0,	
yycrank+107,	0,		0,	
yycrank+117,	0,		0,	
yycrank+126,	0,		0,	
yycrank+0,	0,		yyvstop+63,
yycrank+108,	0,		0,	
yycrank+0,	0,		yyvstop+65,
yycrank+122,	0,		0,	
yycrank+126,	0,		0,	
yycrank+105,	0,		0,	
yycrank+131,	0,		0,	
yycrank+132,	0,		0,	
yycrank+0,	0,		yyvstop+67,
yycrank+0,	0,		yyvstop+69,
yycrank+0,	0,		yyvstop+71,
yycrank+129,	0,		0,	
yycrank+130,	0,		0,	
yycrank+0,	0,		yyvstop+73,
yycrank+118,	0,		0,	
yycrank+0,	0,		yyvstop+75,
yycrank+133,	0,		0,	
yycrank+126,	0,		0,	
yycrank+138,	0,		0,	
yycrank+0,	0,		yyvstop+77,
yycrank+131,	0,		0,	
yycrank+136,	0,		0,	
yycrank+122,	0,		0,	
yycrank+125,	0,		0,	
yycrank+120,	0,		0,	
yycrank+121,	0,		0,	
yycrank+0,	0,		yyvstop+79,
yycrank+126,	0,		0,	
yycrank+0,	0,		yyvstop+81,
yycrank+133,	0,		0,	
yycrank+127,	0,		0,	
yycrank+0,	0,		yyvstop+83,
yycrank+144,	0,		0,	
yycrank+145,	0,		0,	
yycrank+131,	0,		0,	
yycrank+132,	0,		0,	
yycrank+145,	0,		0,	
yycrank+151,	0,		0,	
yycrank+136,	0,		0,	
yycrank+0,	0,		yyvstop+85,
yycrank+142,	0,		0,	
yycrank+0,	0,		yyvstop+87,
yycrank+0,	0,		yyvstop+90,
yycrank+0,	0,		yyvstop+92,
yycrank+152,	0,		0,	
yycrank+0,	0,		yyvstop+95,
yycrank+155,	0,		0,	
yycrank+0,	0,		yyvstop+97,
yycrank+134,	0,		0,	
yycrank+0,	0,		yyvstop+99,
0,	0,	0};
struct yywork *yytop = yycrank+255;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.6 88/02/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
