extern char *malloc(), *realloc();

# line 3 "gram.y"
#include <stdio.h>
#include <math.h>
#include "text3d.h"

extern	void	bdraw();
extern	void	sdraw();

extern	attribs	attr;

extern	int	verbose;


# line 16 "gram.y"
typedef union {
	float		y_flt;
	int		y_int;
	char		*y_str;
} YYSTYPE;
# define FLOAT 257
# define INTEGER 258
# define OPTION 259
# define STRING 260
# define DRAWSTR 261
# define TEXTSIZE 262
# define COLOUR 263
# define AMBIENT 264
# define REFLECTANCE 265
# define TRANSPARENCY 266
# define MATERIAL 267
# define TEXTRADIUS 268
# define FIXEDWIDTH 269
# define CENTERTEXT 270
# define TEXTANG 271
# define FONT 272
# define CHAR 273
# define DRAWCHAR 274
# define BOXFIT 275
# define BOXTEXT 276
# define MOVE 277
# define RMOVE 278
# define SCALE 279
# define TRANSLATE 280
# define ROTATE 281
# define OUTPUT 282
# define BOX_CYL 283
# define CYL_SPH 284
# define LP 285
# define RP 286
# define LBRACE 287
# define RBRACE 288
# define COMMA 289
# define ON 290
# define OFF 291
# define TRUE 292
# define FALSE 293
# define PCENT 294
# define PLUS 295
# define MINUS 296
# define MULT 297
# define DIV 298
# define POWER 299
# define UMINUS 300
# define EQUALS 301
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256
int yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 35
# define YYLAST 427
int yyact[]={

   151,   150,    79,    80,   153,   147,    77,    78,    79,    80,
    77,    78,    79,    80,    77,    78,    79,    80,   146,    61,
    62,    94,   145,    59,    60,    92,   144,    77,    78,    79,
    80,    77,    78,    79,    80,    77,    78,    79,    80,   143,
   142,    91,    90,    89,    75,    77,    78,    79,    80,    77,
    78,    79,    80,   141,   140,    74,    73,   152,   139,    77,
    78,    79,    80,    77,    78,    79,    80,    77,    78,    79,
    80,   129,    44,    46,    47,    64,    43,    42,   128,    41,
    77,    78,    79,    80,    77,    78,    79,    80,   127,    40,
    39,    38,   126,    37,    77,    78,    79,    80,    77,    78,
    79,    80,   125,    36,    35,    34,   124,    33,    77,    78,
    79,    80,    77,    78,    79,    80,   123,    32,    31,    30,
   122,    29,    77,    78,    79,    80,    77,    78,    79,    80,
   121,    28,    27,    26,   120,   119,    77,    78,    79,    80,
    77,    78,    79,    80,    77,    78,    79,    80,   108,    25,
    24,    45,     2,     1,     0,   102,     0,    77,    78,    79,
    80,    77,    78,    79,    80,   101,     0,     0,     0,   100,
     0,    77,    78,    79,    80,    77,    78,    79,    80,    99,
     0,     0,     0,    98,     0,    77,    78,    79,    80,    77,
    78,    79,    80,    97,     0,     0,     0,    96,    95,    77,
    78,    79,    80,    77,    78,    79,    80,    77,    78,    79,
    80,    93,     0,     0,     0,    88,     0,     0,     0,     0,
    77,    78,    79,    80,    77,    78,    79,    80,    87,    86,
     0,     0,     0,    85,    77,    78,    79,    80,    77,    78,
    79,    80,    77,    78,    79,    80,    84,     0,     0,     0,
    83,     0,    77,    78,    79,    80,    77,    78,    79,    80,
    76,     0,     0,     0,    49,    50,    77,    78,    79,    80,
     3,     5,     6,     7,     8,     9,    10,    11,    13,    12,
    14,    15,    48,    16,    17,    18,    19,    20,    21,    22,
    23,     4,    52,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    51,     0,     0,     0,     0,     0,     0,
    53,    54,    55,    56,    57,    58,     0,     0,    63,     0,
    65,    66,    67,    68,    69,    70,    71,    72,     0,     0,
     0,     0,     0,     0,    81,    82,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   103,
   104,   105,   106,   107,     0,     0,   109,   110,     0,     0,
   111,     0,     0,     0,     0,     0,     0,     0,     0,   112,
   113,   114,   115,   116,   117,   118,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   130,   131,   132,   133,   134,   135,   136,
   137,   138,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   148,     0,   149 };
int yypact[]={

 -1000,     9, -1000,  -135,  -136,  -152,  -153,  -154,  -164,  -166,
  -167,  -168,  -178,  -180,  -181,  -182,  -192,  -194,  -195,  -196,
  -206,  -208,  -209,  -213,  -109,  -210,     7,     7,     7,     7,
     7,     7,     7,  -269,  -273,     7,  -185,     7,     7,     7,
     7,     7,     7,     7,     7,  -230,  -231,  -242,   -29, -1000,
 -1000,     7,     7,   -39,   -43,   -53,   -57,   -61,   -71,  -243,
  -244,  -245,  -261,   -75,  -265,   -88,   -92,   -96,  -106,  -110,
  -120,  -124,  -134, -1000, -1000, -1000,     7,     7,     7,     7,
     7, -1000,  -138,     7,     7, -1000, -1000,     7, -1000, -1000,
 -1000, -1000, -1000, -1000, -1000, -1000,     7,     7,     7,     7,
     7,     7,     7,  -151,  -295,  -295, -1000, -1000, -1000,  -155,
  -159,  -169,  -173,  -183,  -187,  -197,  -201,  -211,  -215, -1000,
     7,     7,     7,     7,     7,     7,     7,     7,     7, -1000,
  -228,  -232,  -236,  -246,  -250,  -260,  -264,  -268,  -281, -1000,
 -1000,     7, -1000,     7, -1000, -1000, -1000, -1000,  -285,  -289,
 -1000,  -203,  -282, -1000 };
int yypgo[]={

     0,   282,   153,   152 };
int yyr1[]={

     0,     2,     2,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     1,     1,     1,
     1,     1,     1,     1,     1 };
int yyr2[]={

     0,     0,     4,     9,     9,     9,    13,    17,    17,     9,
     9,    21,     9,     9,     9,     9,     9,     9,     9,     9,
    17,    25,    17,    17,    17,    17,    13,     3,     3,     7,
     7,     7,     7,     5,     7 };
int yychk[]={

 -1000,    -2,    -3,   261,   282,   262,   263,   264,   265,   266,
   267,   268,   270,   269,   271,   272,   274,   275,   276,   277,
   278,   279,   280,   281,   285,   285,   285,   285,   285,   285,
   285,   285,   285,   285,   285,   285,   285,   285,   285,   285,
   285,   285,   285,   285,   285,   260,   283,   284,    -1,   257,
   258,   296,   285,    -1,    -1,    -1,    -1,    -1,    -1,   292,
   293,   292,   293,    -1,   260,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   286,   286,   286,   289,   295,   296,   297,
   298,    -1,    -1,   289,   289,   286,   286,   289,   286,   286,
   286,   286,   286,   286,   286,   286,   289,   289,   289,   289,
   289,   289,   289,    -1,    -1,    -1,    -1,    -1,   286,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   286,
   289,   289,   289,   289,   289,   289,   289,   289,   289,   286,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   286,
   286,   289,   286,   289,   286,   286,   286,   286,    -1,    -1,
   286,   289,   260,   286 };
int yydef[]={

     1,    -2,     2,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    27,
    28,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     3,     4,     5,     0,     0,     0,     0,
     0,    33,     0,     0,     0,     9,    10,     0,    12,    13,
    14,    15,    16,    17,    18,    19,     0,     0,     0,     0,
     0,     0,     0,     0,    29,    30,    31,    32,    34,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     6,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    26,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     7,
     8,     0,    20,     0,    22,    23,    24,    25,     0,     0,
    11,     0,     0,    21 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"FLOAT",	257,
	"INTEGER",	258,
	"OPTION",	259,
	"STRING",	260,
	"DRAWSTR",	261,
	"TEXTSIZE",	262,
	"COLOUR",	263,
	"AMBIENT",	264,
	"REFLECTANCE",	265,
	"TRANSPARENCY",	266,
	"MATERIAL",	267,
	"TEXTRADIUS",	268,
	"FIXEDWIDTH",	269,
	"CENTERTEXT",	270,
	"TEXTANG",	271,
	"FONT",	272,
	"CHAR",	273,
	"DRAWCHAR",	274,
	"BOXFIT",	275,
	"BOXTEXT",	276,
	"MOVE",	277,
	"RMOVE",	278,
	"SCALE",	279,
	"TRANSLATE",	280,
	"ROTATE",	281,
	"OUTPUT",	282,
	"BOX_CYL",	283,
	"CYL_SPH",	284,
	"LP",	285,
	"RP",	286,
	"LBRACE",	287,
	"RBRACE",	288,
	"COMMA",	289,
	"ON",	290,
	"OFF",	291,
	"TRUE",	292,
	"FALSE",	293,
	"PCENT",	294,
	"PLUS",	295,
	"MINUS",	296,
	"MULT",	297,
	"DIV",	298,
	"POWER",	299,
	"UMINUS",	300,
	"EQUALS",	301,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"input : /* empty */",
	"input : input item",
	"item : DRAWSTR LP STRING RP",
	"item : OUTPUT LP BOX_CYL RP",
	"item : OUTPUT LP CYL_SPH RP",
	"item : TEXTSIZE LP expr COMMA expr RP",
	"item : COLOUR LP expr COMMA expr COMMA expr RP",
	"item : AMBIENT LP expr COMMA expr COMMA expr RP",
	"item : REFLECTANCE LP expr RP",
	"item : TRANSPARENCY LP expr RP",
	"item : MATERIAL LP expr COMMA expr COMMA expr COMMA expr RP",
	"item : TEXTRADIUS LP expr RP",
	"item : CENTERTEXT LP TRUE RP",
	"item : CENTERTEXT LP FALSE RP",
	"item : FIXEDWIDTH LP TRUE RP",
	"item : FIXEDWIDTH LP FALSE RP",
	"item : TEXTANG LP expr RP",
	"item : FONT LP STRING RP",
	"item : DRAWCHAR LP expr RP",
	"item : BOXFIT LP expr COMMA expr COMMA expr RP",
	"item : BOXTEXT LP expr COMMA expr COMMA expr COMMA expr COMMA STRING RP",
	"item : MOVE LP expr COMMA expr COMMA expr RP",
	"item : RMOVE LP expr COMMA expr COMMA expr RP",
	"item : SCALE LP expr COMMA expr COMMA expr RP",
	"item : TRANSLATE LP expr COMMA expr COMMA expr RP",
	"item : ROTATE LP expr COMMA expr RP",
	"expr : FLOAT",
	"expr : INTEGER",
	"expr : expr PLUS expr",
	"expr : expr MINUS expr",
	"expr : expr MULT expr",
	"expr : expr DIV expr",
	"expr : MINUS expr",
	"expr : LP expr RP",
};
#endif /* YYDEBUG */
#line 1 "/usr/lib/yaccpar"
/*	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	*/

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	{ free(yys); free(yyv); return(0); }
#define YYABORT		{ free(yys); free(yyv); return(1); }
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-1000)

/*
** static variables used by the parser
*/
static YYSTYPE *yyv;			/* value stack */
static int *yys;			/* state stack */

static YYSTYPE *yypv;			/* top of value stack */
static int *yyps;			/* top of state stack */

static int yystate;			/* current state */
static int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */

int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */


/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */
	unsigned yymaxdepth = YYMAXDEPTH;

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yyv = (YYSTYPE*)malloc(yymaxdepth*sizeof(YYSTYPE));
	yys = (int*)malloc(yymaxdepth*sizeof(int));
	if (!yyv || !yys)
	{
		yyerror( "out of memory" );
		return(1);
	}
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			(void)printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			yymaxdepth += YYMAXDEPTH;
			yyv = (YYSTYPE*)realloc((char*)yyv,
				yymaxdepth * sizeof(YYSTYPE));
			yys = (int*)realloc((char*)yys,
				yymaxdepth * sizeof(int));
			if (!yyv || !yys)
			{
				yyerror( "yacc stack overflow" );
				return(1);
			}
			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			(void)printf( "Received token " );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				(void)printf( "Received token " );
				if ( yychar == 0 )
					(void)printf( "end-of-file\n" );
				else if ( yychar < 0 )
					(void)printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					(void)printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						(void)printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					(void)printf( "Error recovery discards " );
					if ( yychar == 0 )
						(void)printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						(void)printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						(void)printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			(void)printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 3:
# line 48 "gram.y"
{
		drawstr(yypvt[-1].y_str);
		if (verbose)
			fprintf(stderr, "drawstr(\"%s\")\n", yypvt[-1].y_str);
	  } break;
case 4:
# line 54 "gram.y"
{
		attr.drawfun = bdraw;
		if (verbose)
			fprintf(stderr, "output(box_cyl)\n");
	  } break;
case 5:
# line 60 "gram.y"
{
		attr.drawfun = sdraw;
		if (verbose)
			fprintf(stderr, "output(cyl_sph)\n");
	  } break;
case 6:
# line 66 "gram.y"
{
		textsize(yypvt[-3].y_flt, yypvt[-1].y_flt);
		if (verbose)
			fprintf(stderr, "textsize(%g, %g)\n", yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 7:
# line 72 "gram.y"
{
		attr.col_set = 1;
		attr.col.r = yypvt[-5].y_flt;
		attr.col.g = yypvt[-3].y_flt;
		attr.col.b = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "colour(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 8:
# line 81 "gram.y"
{
		attr.amb_set = 1;
		attr.amb.r = yypvt[-5].y_flt;
		attr.amb.g = yypvt[-3].y_flt;
		attr.amb.b = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "ambient(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 9:
# line 90 "gram.y"
{
		attr.ref_set = 1;
		attr.refl = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "reflectance(%g)\n", yypvt[-1].y_flt);
	  } break;
case 10:
# line 97 "gram.y"
{
		attr.trans_set = 1;
		attr.trans = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "transparency(%g)\n", yypvt[-1].y_flt);
	  } break;
case 11:
# line 104 "gram.y"
{
		attr.mat_set = 1;
		attr.mat.ri = yypvt[-7].y_flt;
		attr.mat.kd = yypvt[-5].y_flt;
		attr.mat.ks = yypvt[-3].y_flt;
		attr.mat.ksexp = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "material(%g, %g, %g, %g)\n", yypvt[-7].y_flt, yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 12:
# line 114 "gram.y"
{
		attr.radius = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "textradius(%g)\n", yypvt[-1].y_flt);
	  } break;
case 13:
# line 120 "gram.y"
{
		attr.centered = 1;
		if (verbose)
			fprintf(stderr, "centretext(true)\n");
	  } break;
case 14:
# line 126 "gram.y"
{
		attr.centered = 0;
		if (verbose)
			fprintf(stderr, "centretext(false)\n");
	  } break;
case 15:
# line 132 "gram.y"
{
		attr.fixedwidth = 1;
		if (verbose)
			fprintf(stderr, "fixedwidth(true)\n");
	  } break;
case 16:
# line 138 "gram.y"
{
		attr.fixedwidth = 0;
		if (verbose)
			fprintf(stderr, "fixedwidth(false)\n");
	  } break;
case 17:
# line 144 "gram.y"
{
		double	ang = yypvt[-1].y_flt;
	
		attr.textcos = cos(ang * D2R);
		attr.textsin = sin(ang * D2R);
		if (verbose)
			fprintf(stderr, "textang(%g)\n", yypvt[-1].y_flt);
	  } break;
case 18:
# line 153 "gram.y"
{
		font(yypvt[-1].y_str);
		if (verbose)
			fprintf(stderr, "font(\"%s\")\n", yypvt[-1].y_str);
	  } break;
case 19:
# line 159 "gram.y"
{
		int	ch = (int)yypvt[-1].y_flt;

		drawchar(ch);

		if (verbose)
			if (ch < 32 || ch > 127)
				fprintf(stderr, "drawchar(%d)\n", ch);
			else
				fprintf(stderr, "drawchar('%c')\n", ch);

	  } break;
case 20:
# line 172 "gram.y"
{
		int	n = (int)yypvt[-1].y_flt;

		boxfit(yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
		if (verbose)
			fprintf(stderr, "boxfit(%g, %g, %d)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, n);
	  } break;
case 21:
# line 180 "gram.y"
{
		boxtext(yypvt[-9].y_flt, yypvt[-7].y_flt, yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_str);
		if (verbose)
			fprintf(stderr, "boxtext(%g, %g, %g, %g, %s)\n", yypvt[-9].y_flt, yypvt[-7].y_flt, yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_str);
	  } break;
case 22:
# line 186 "gram.y"
{
		move(yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
		if (verbose)
			fprintf(stderr, "move(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 23:
# line 192 "gram.y"
{
		rmove(yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
		if (verbose)
			fprintf(stderr, "rmove(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 24:
# line 198 "gram.y"
{
		attr.scal_set = 1;
		attr.scal.x = yypvt[-5].y_flt;
		attr.scal.y = yypvt[-3].y_flt;
		attr.scal.z = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "scale(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 25:
# line 207 "gram.y"
{
		attr.trans_set = 1;
		attr.tran.x = yypvt[-5].y_flt;
		attr.tran.y = yypvt[-3].y_flt;
		attr.tran.z = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "translate(%g, %g, %g)\n", yypvt[-5].y_flt, yypvt[-3].y_flt, yypvt[-1].y_flt);
	  } break;
case 26:
# line 216 "gram.y"
{
		attr.rot_set = 1;
		attr.rot.ang = yypvt[-3].y_flt;
		attr.rot.ax = yypvt[-1].y_flt;
		if (verbose)
			fprintf(stderr, "rotate(%g, %c)\n", attr.rot.ang, attr.rot.ax);
	  } break;
case 27:
# line 226 "gram.y"
{
		yyval.y_flt = yypvt[-0].y_flt;
	  } break;
case 28:
# line 230 "gram.y"
{
		yyval.y_flt = yypvt[-0].y_int;
	  } break;
case 29:
# line 234 "gram.y"
{
		yyval.y_flt = yypvt[-2].y_flt + yypvt[-0].y_flt;
	  } break;
case 30:
# line 238 "gram.y"
{
		yyval.y_flt = yypvt[-2].y_flt - yypvt[-0].y_flt;
	  } break;
case 31:
# line 242 "gram.y"
{
		yyval.y_flt = yypvt[-2].y_flt * yypvt[-0].y_flt;
	  } break;
case 32:
# line 246 "gram.y"
{
		yyval.y_flt = yypvt[-2].y_flt / yypvt[-0].y_flt;
	  } break;
case 33:
# line 250 "gram.y"
{
		yyval.y_flt = -yypvt[-0].y_flt;
	  } break;
case 34:
# line 254 "gram.y"
{
		yyval.y_flt = yypvt[-1].y_flt;
	  } break;
	}
	goto yystack;		/* reset registers in driver code */
}
