
typedef union {
	float		y_flt;
	int		y_int;
	char		*y_str;
} YYSTYPE;
extern YYSTYPE yylval;
# define FLOAT 257
# define INTEGER 258
# define OPTION 259
# define STRING 260
# define DRAWSTR 261
# define TEXTSIZE 262
# define COLOUR 263
# define AMBIENT 264
# define REFLECTANCE 265
# define TRANSPARENCY 266
# define MATERIAL 267
# define TEXTRADIUS 268
# define FIXEDWIDTH 269
# define CENTERTEXT 270
# define TEXTANG 271
# define FONT 272
# define CHAR 273
# define DRAWCHAR 274
# define BOXFIT 275
# define BOXTEXT 276
# define MOVE 277
# define RMOVE 278
# define SCALE 279
# define TRANSLATE 280
# define ROTATE 281
# define OUTPUT 282
# define BOX_CYL 283
# define CYL_SPH 284
# define LP 285
# define RP 286
# define LBRACE 287
# define RBRACE 288
# define COMMA 289
# define ON 290
# define OFF 291
# define TRUE 292
# define FALSE 293
# define PCENT 294
# define PLUS 295
# define MINUS 296
# define MULT 297
# define DIV 298
# define POWER 299
# define UMINUS 300
# define EQUALS 301
