/*
 * Helper routines for V/EGA routines of VORT PCDISP.
 */

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

#ifdef TC
extern unsigned _stklen;
#endif
	
static	union	REGS	regs;
static	struct	SREGS	segregs;



/*
 * Set the colour palette.
 */

int			vega_palette(palette, size)
char		*palette;
int			size;
{
	regs.x.ax = 0x1012;
	regs.x.bx = 0x0000;
	regs.x.cx = size;
	regs.x.dx = FP_OFF(palette);
	segregs.es= FP_SEG(palette);
	int86x(0x10, &regs, &regs, &segregs);
}




/*
 * Set the overscan palette index.
 */

int			vega_overscan(index)
int			index;
{
	regs.x.ax = 0x1001;
	regs.h.bh = index;
	int86(0x10, &regs, &regs);
}

