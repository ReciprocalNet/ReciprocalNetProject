#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vort.h>
#include "fgraph.h"

#define MAXVIDEO 9
#define MAX_IMGWIDTH 1280
#define PALETTE_SIZE 256

#define YES 1
#define NO 0

#define REDPLANE 1
#define GREENPLANE 2
#define BLUEPLANE 3
#define FULLCOLORS 100
#define MONOCHROME 101
#define TRICKYL 200
#define TRICKYS 300
#define TRICKY2S 301

#define gotographics(zz)  { startgraphics(zz); gort=1; }
#define returntotext() { if (gort) settextmode(); gort=0; }

#ifndef DEF_VARS
extern image *im;
extern int autosave, options, videomode, centering, showtitle;
extern long imagewait, titlewait;
extern int dismode, disxw, disyw, gort;
extern unsigned char *r[2], *g[2], *b[2], *s[2];
extern char prname[], trickyd[10];
extern int videos[10][3];
extern int tricklen;
#else
image *im;
int autosave, options, centering, videomode, showtitle;
long imagewait, titlewait;
int dismode, disxw, disyw, gort=0;
unsigned char *r[2], *g[2], *b[2], *s[2];
char prname[]="Showpix 3.0, display Vort files on (nearly) any adapter.";
int videos[10][3]= { { IBMMCGA320200256, 320, 200 },
                     { TWKVGA360480256, 360, 480 },
                     { SUPVGA640400256, 640, 400 },
                     { SUPVGA640480256, 640, 480 },
                     { SUPVGA800600256, 800, 600 },
                     { SUPVGA1024768256, 1024, 768 },
                     { SUPVGA12801024256, 1280, 1024 },
                     { IBM8514640480256, 640, 480 },
                     { IBM85141024768256, 1024, 768 } };
char trickyd[10];
int tricklen;
#endif

extern int savegif(char *);

extern void buildcline(int, char **);
extern void getoptions(int *, int *, int *);
extern int getnextname(char *);

int setvideostats(int);
void display_image(int, int, int, int);

void help(char *);
int readkey(long);
