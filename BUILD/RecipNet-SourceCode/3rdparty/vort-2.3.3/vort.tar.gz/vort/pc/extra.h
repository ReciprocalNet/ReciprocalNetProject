/* funcion prototypes for extra.obj */
extern int extraseg;

extern void toextra(int, unsigned char *, int);
extern void fromextra(int, unsigned char *, int);
extern int  cmpextra(int, unsigned char *, int);
